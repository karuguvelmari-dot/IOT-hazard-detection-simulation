
#include <DHTesp.h>

#define DHT_PIN 15
#define MQ2_PIN 34
#define WATER_PIN 35
#define BUZZER_PIN 25

DHTesp dhtSensor;

void setup() {
  Serial.begin(115200);

  dhtSensor.setup(DHT_PIN, DHTesp::DHT22);

  pinMode(MQ2_PIN, INPUT);
  pinMode(WATER_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  analogReadResolution(12);

  Serial.println("SENTINEL AI - MULTI HAZARD SIMULATOR");
  Serial.println("Temp,Humidity,SmokeGas,Water,Hazard,Risk");
}

void loop() {
  TempAndHumidity dht = dhtSensor.getTempAndHumidity();

  int smoke = map(analogRead(MQ2_PIN), 0, 4095, 0, 100);
  int water = map(analogRead(WATER_PIN), 0, 4095, 0, 100);

  float temp = dht.temperature;
  float humidity = dht.humidity;

  String hazard = "NORMAL";
  int risk = 5;

  if (smoke >= 75 && temp >= 50) {
    hazard = "FIRE";
    risk = 95;
  } else if (water >= 75) {
    hazard = "FLOOD";
    risk = 90;
  } else if (smoke >= 75) {
    hazard = "GAS_LEAKAGE";
    risk = 85;
  } else if (temp >= 50) {
    hazard = "ABNORMAL_TEMPERATURE";
    risk = 70;
  } else if (smoke >= 50 || water >= 50) {
    hazard = "WARNING";
    risk = 40;
  }

  if (risk >= 70) {
    tone(BUZZER_PIN, 2000);
  } else {
    noTone(BUZZER_PIN);
  }

  Serial.printf("%.1f,%.1f,%d,%d,%s,%d\n",
                temp, humidity, smoke, water,
                hazard.c_str(), risk);

  delay(2000);
}
